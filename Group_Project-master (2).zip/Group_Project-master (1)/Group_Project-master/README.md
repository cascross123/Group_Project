# Group_Project
-the exe are in WindowsFormsApplication1/bin/debug and Chat Server/bin/debug
-need 2 windows of the chat client open and 1 of the server
-will work fine on the same computer, for networked you will have to open the file in VS and edit the marked ip to the ip of the computer
that has the server open.
-to activate the ai put PCPartPickerG10 as one of the usernames.
